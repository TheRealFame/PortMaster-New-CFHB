import GemRB

def OpenQuitMsgWindow():
	GemRB.QuitGame()
	GemRB.Quit()
